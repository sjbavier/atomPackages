{-# LANGUAGE Wat #-}
import    Foo
import Bar

import qualified Baz as Bang

data Person = Person {
  name :: String,
  address :: String
}
