{-# LANGUAGE Wat #-}
import           Bar
import           Foo

import qualified Baz as Bang

data Person = Person {
  name    :: String,
  address :: String
}
