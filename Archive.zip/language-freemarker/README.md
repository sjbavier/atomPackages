# Freemarker language support in Atom

Adds syntax highlighting and snippets to Freemarker files in Atom.

Originally [converted](http://atom.io/docs/latest/converting-a-text-mate-bundle)
from the [Freemarker TextMate bundle](https://github.com/briancavalier/textmate-freemarker-bundle).

Contributions are greatly appreciated. Please fork this repository and open a
pull request to add snippets, make grammar tweaks, etc.
